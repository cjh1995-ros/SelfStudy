from tensorflow.keras.models import load_model

model = load_model('../dlib-models/Mymodel3.h5')
print(model.summary())
