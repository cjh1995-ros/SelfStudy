import RPi.GPIO as gp
import time 

gp.setwarnings(False)
gp.setmode(gp.BCM)
gp.setup(15, gp.OUT)

print("boozer start!")
print("*"*50)

while True:
    print("sleep")
    gp.output(15, True)
    time.sleep(1)
    print("booz")
    gp.output(15, False)
    time.sleep(1)

