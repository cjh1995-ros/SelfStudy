import cv2
import dlib
import numpy as np
import sys

detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor('dlib-models/shape_predictor_68_face_landmarks.dat')

cap = cv2.VideoCapture(0)

All = list(range(0,68))
Right_Eye = list(range(36,42))
Left_Eye = list(range(42,48))

Index = All

while True:
    ret, img = cap.read()
    if ret == False:
        print("cant read image-- step 1")
        sys.exit(-1)
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    dets = detector(img_gray,1)

    for face in dets:
        shape = predictor(img, face) # find 68 points

        list_points = []
        for p in shape.parts():
            list_points.append([p.x, p.y])
        list_points = np.array(list_points)

        for i, pt in enumerate(list_points[Index]):
            pt_pos = (pt[0], pt[1])
            cv2.circle(img, pt_pos, 2, (0, 255, 0), -1)

        cv2.rectangle(img, (face.left(), face.top()), (face.right(), face.bottom()), (0, 0, 255), 3)
    cv2.imshow("results", img)
    if cv2.waitKey(1) == 27:
        break
    
    elif cv2.waitKey(1) == ord('1'):
        index = All
    elif cv2.waitKey(1) == ord('2'):
        index = Right_Eye
    elif cv2.waitKey(1) == ord('3'):
        index = Left_Eye

cap.release()
